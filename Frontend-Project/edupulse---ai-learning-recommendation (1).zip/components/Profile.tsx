import React, { useState } from 'react';
import { StudentData } from '../types';
import { MOCK_COURSES } from '../data';
import { Save, Trash2, Plus } from 'lucide-react';

interface ProfileProps {
  user: StudentData;
}

const Profile: React.FC<ProfileProps> = ({ user }) => {
  const [formData, setFormData] = useState({
    name: user.name,
    major: user.major,
    semester: user.semester,
    learning_style: user.learning_style,
  });

  const courses = MOCK_COURSES[user.userid] || [];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = () => {
    alert("Perubahan disimpan! (Simulasi update ke Database)");
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-slate-900">Edit Profil & Nilai</h1>
        <button 
          onClick={handleSave}
          className="flex items-center space-x-2 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg transition-colors font-medium"
        >
          <Save className="w-4 h-4" />
          <span>Simpan Perubahan</span>
        </button>
      </div>

      {/* Personal Details Form */}
      <div className="bg-white p-8 rounded-xl shadow-sm border border-slate-100">
        <h2 className="text-lg font-bold text-slate-800 mb-6 border-b pb-4">Detail Pribadi</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Nama Lengkap</label>
            <input 
              type="text" 
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              className="w-full border border-slate-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Jurusan</label>
            <input 
              type="text" 
              name="major"
              value={formData.major}
              onChange={handleInputChange}
              className="w-full border border-slate-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Semester Saat Ini</label>
            <input 
              type="number" 
              name="semester"
              value={formData.semester}
              onChange={handleInputChange}
              className="w-full border border-slate-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Gaya Belajar</label>
            <select 
              name="learning_style"
              value={formData.learning_style}
              onChange={handleInputChange}
              className="w-full border border-slate-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none bg-white"
            >
              <option value="Visual">Visual</option>
              <option value="Auditory">Auditory</option>
              <option value="Kinesthetic">Kinesthetic</option>
              <option value="Reading/Writing">Reading/Writing</option>
            </select>
          </div>
        </div>
      </div>

      {/* Courses Table */}
      <div className="bg-white p-8 rounded-xl shadow-sm border border-slate-100">
        <div className="flex justify-between items-center mb-6 border-b pb-4">
          <h2 className="text-lg font-bold text-slate-800">Nilai Mata Kuliah</h2>
          <button className="flex items-center space-x-2 text-sm bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-2 rounded-lg transition-colors">
            <Plus className="w-4 h-4" />
            <span>Tambah Matkul</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="text-xs text-slate-500 uppercase tracking-wider border-b border-slate-100">
                <th className="pb-3 pl-4">Kode</th>
                <th className="pb-3">Nama Mata Kuliah</th>
                <th className="pb-3">Nilai (0-100)</th>
                <th className="pb-3">SKS</th>
                <th className="pb-3 text-right pr-4">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {courses.map((course, idx) => (
                <tr key={idx} className="hover:bg-slate-50">
                  <td className="py-4 pl-4 text-sm font-medium text-slate-600">{course.code}</td>
                  <td className="py-4 text-sm text-slate-900 font-medium">{course.name}</td>
                  <td className="py-4 text-sm text-slate-700 font-bold">{course.score}</td>
                  <td className="py-4 text-sm text-slate-600">{course.sks}</td>
                  <td className="py-4 text-right pr-4">
                    <button className="text-red-400 hover:text-red-600 transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {courses.length === 0 && (
             <p className="text-center py-8 text-slate-400 text-sm">Belum ada data nilai.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default Profile;
