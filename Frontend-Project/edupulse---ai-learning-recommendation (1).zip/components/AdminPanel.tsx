import React, { useState } from 'react';
import { MOCK_STUDENTS } from '../data';
import { Search, Eye, AlertTriangle } from 'lucide-react';
import Dashboard from './Dashboard';

const AdminPanel: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedStudentId, setSelectedStudentId] = useState<number | null>(null);

  const filteredStudents = MOCK_STUDENTS.filter(s => 
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    s.major.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const atRiskCount = MOCK_STUDENTS.filter(s => s.performance_category === 'Low').length;
  const avgGPA = (MOCK_STUDENTS.reduce((acc, curr) => acc + curr.gpa, 0) / MOCK_STUDENTS.length).toFixed(2);

  // If a student is selected, show their dashboard (Admin POV)
  if (selectedStudentId) {
    const student = MOCK_STUDENTS.find(s => s.userid === selectedStudentId);
    if (!student) return null;

    return (
      <div className="space-y-6">
        <button 
          onClick={() => setSelectedStudentId(null)}
          className="flex items-center text-slate-500 hover:text-slate-800 transition-colors"
        >
          ← Kembali ke Daftar Mahasiswa
        </button>
        <div className="border-t border-slate-200 pt-6">
           <div className="bg-amber-50 border border-amber-200 text-amber-800 px-4 py-2 rounded-lg mb-6 text-sm">
             👀 Mode Tampilan Admin: Melihat data sebagai <strong>{student.name}</strong>
           </div>
           <Dashboard user={student} />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-bold text-slate-900">Manajemen Mahasiswa</h1>

      {/* Admin Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
           <p className="text-slate-500 text-sm font-medium mb-1">Total Mahasiswa</p>
           <p className="text-3xl font-bold text-slate-800">{MOCK_STUDENTS.length}</p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
           <p className="text-slate-500 text-sm font-medium mb-1">Rata-rata IPK</p>
           <p className="text-3xl font-bold text-emerald-600">{avgGPA}</p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex items-center justify-between">
           <div>
             <p className="text-slate-500 text-sm font-medium mb-1">Mahasiswa Berisiko</p>
             <p className="text-3xl font-bold text-red-600">{atRiskCount}</p>
           </div>
           <div className="bg-red-50 p-3 rounded-full">
             <AlertTriangle className="text-red-500 w-6 h-6" />
           </div>
        </div>
      </div>

      {/* Table Section */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <h2 className="font-bold text-lg text-slate-800">Daftar Mahasiswa</h2>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
            <input 
              type="text" 
              placeholder="Cari nama atau jurusan..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 w-full md:w-64"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase font-medium">
              <tr>
                <th className="px-6 py-4">Nama</th>
                <th className="px-6 py-4">Jurusan</th>
                <th className="px-6 py-4">Cluster</th>
                <th className="px-6 py-4">Rata-rata Nilai</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStudents.map((student) => (
                <tr key={student.userid} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                      <span className="font-medium text-slate-900">{student.name}</span>
                      <span className="text-xs text-slate-500">{student.userid}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-600">{student.major}</td>
                  <td className="px-6 py-4">
                     <span className="bg-slate-100 text-slate-600 px-2 py-1 rounded text-xs font-bold">
                       {student.cluster}
                     </span>
                  </td>
                  <td className="px-6 py-4 text-sm font-medium text-slate-800">{student.mean_score_pct.toFixed(1)}%</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      student.performance_category === 'High' ? 'bg-emerald-100 text-emerald-700' :
                      student.performance_category === 'Medium' ? 'bg-blue-100 text-blue-700' :
                      'bg-red-100 text-red-700'
                    }`}>
                      {student.performance_category}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button 
                      onClick={() => setSelectedStudentId(student.userid)}
                      className="text-red-600 hover:text-red-800 text-sm font-medium inline-flex items-center gap-1"
                    >
                      Lihat Detail <Eye className="w-3 h-3" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filteredStudents.length === 0 && (
            <div className="p-8 text-center text-slate-500">
              Tidak ada mahasiswa yang ditemukan.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;
