import React, { useState } from 'react';
import { StudentData } from '../types';
import { getRecommendations } from '../data';
import { BrainCircuit, RefreshCw, Book, Video, Users, CheckCircle, Zap } from 'lucide-react';

interface RecProps {
  user: StudentData;
}

const Recommendations: React.FC<RecProps> = ({ user }) => {
  const [analyzing, setAnalyzing] = useState(false);
  const [showResults, setShowResults] = useState(false);

  const handleAnalysis = () => {
    setAnalyzing(true);
    // Simulate ML processing delay
    setTimeout(() => {
      setAnalyzing(false);
      setShowResults(true);
    }, 2000);
  };

  const recommendations = getRecommendations(user);

  if (!showResults && !analyzing) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
            <BrainCircuit className="text-red-600" />
            Mesin Rekomendasi AI
          </h1>
          <button 
            onClick={handleAnalysis}
            className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-lg font-medium shadow-lg shadow-red-200 transition-all transform hover:scale-105"
          >
            Analisis Profil Saya
          </button>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 h-[60vh] flex flex-col items-center justify-center text-center p-8">
          <div className="bg-red-50 p-6 rounded-full mb-6">
            <BrainCircuit className="w-16 h-16 text-red-600" />
          </div>
          <h2 className="text-xl font-bold text-slate-800 mb-2">Siap Mengoptimalkan Pembelajaran?</h2>
          <p className="text-slate-500 max-w-md">
            AI kami akan menganalisis data LMS (nilai, engagement, dan konsistensi) Anda dari Data Engineering pipeline untuk memberikan rencana belajar yang disesuaikan.
          </p>
        </div>
      </div>
    );
  }

  if (analyzing) {
    return (
      <div className="h-[80vh] flex flex-col items-center justify-center">
        <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-red-600 mb-4"></div>
        <p className="text-slate-600 font-medium animate-pulse">Memproses Cluster {user.cluster}...</p>
        <p className="text-slate-400 text-sm mt-2">Menganalisis {user.num_attempts} riwayat kuis...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
          <BrainCircuit className="text-red-600" />
          Hasil Analisis AI
        </h1>
        <button 
          onClick={handleAnalysis}
          className="bg-slate-800 hover:bg-slate-900 text-white px-4 py-2 rounded-lg font-medium flex items-center gap-2 text-sm transition-colors"
        >
          <RefreshCw className="w-4 h-4" />
          Analisis Ulang
        </button>
      </div>

      {/* Executive Summary */}
      <div className="bg-gradient-to-r from-red-900 to-red-700 rounded-xl p-8 text-white shadow-lg relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10">
            <BrainCircuit className="w-64 h-64" />
        </div>
        <div className="relative z-10">
            <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
                <Zap className="w-5 h-5 text-yellow-400" />
                Ringkasan Eksekutif
            </h2>
            <p className="leading-relaxed text-red-50 max-w-3xl">
                {user.name}, Anda berada di <strong>Cluster {user.cluster}</strong> dengan kategori performa <strong>{user.performance_category}</strong>. 
                Sistem mendeteksi bahwa {user.consistency_score < 0.2 ? 'konsistensi belajar Anda perlu ditingkatkan' : 'Anda memiliki konsistensi belajar yang baik'}. 
                Dengan skor engagement {user.engagement_score}, kami merekomendasikan fokus pada {user.mean_score_pct < 60 ? 'pemahaman dasar' : 'pengayaan materi'} berikut ini.
            </p>
        </div>
      </div>

      {/* Recommendation Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {recommendations.map((rec, idx) => {
            let Icon = Book;
            let color = "bg-blue-50 text-blue-600";
            if (rec.type === 'Strategy') { Icon = CheckCircle; color = "bg-green-50 text-green-600"; }
            if (rec.type === 'Activity') { Icon = Users; color = "bg-purple-50 text-purple-600"; }
            if (rec.type === 'Alert') { Icon = Zap; color = "bg-amber-50 text-amber-600"; }

            return (
                <div key={idx} className="bg-white rounded-xl p-6 shadow-sm border border-slate-100 flex flex-col hover:shadow-md transition-shadow">
                    <div className="flex justify-between items-start mb-4">
                        <div className={`p-3 rounded-lg ${color}`}>
                            <Icon className="w-6 h-6" />
                        </div>
                        <span className="bg-slate-100 text-slate-600 text-xs font-bold px-2 py-1 rounded">
                            {rec.match}% Cocok
                        </span>
                    </div>
                    
                    <h3 className="font-bold text-slate-800 mb-2">{rec.title}</h3>
                    <p className="text-slate-500 text-sm mb-6 flex-1">{rec.desc}</p>
                    
                    <div className="pt-4 border-t border-slate-50">
                        <p className="text-xs text-slate-400 font-medium uppercase tracking-wide mb-1">
                            {rec.type === 'Course' ? 'Online Course' : 'Learning Strategy'}
                        </p>
                        <a href={rec.link} className="text-red-600 text-sm font-medium hover:underline">
                            Lihat Detail →
                        </a>
                    </div>
                </div>
            );
        })}
      </div>
    </div>
  );
};

export default Recommendations;
