import React from 'react';
import { StudentData } from '../types';
import { MOCK_COURSES } from '../data';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer 
} from 'recharts';
import { TrendingUp, Award, Clock, AlertCircle } from 'lucide-react';

interface DashboardProps {
  user: StudentData;
}

const Dashboard: React.FC<DashboardProps> = ({ user }) => {
  const courses = MOCK_COURSES[user.userid] || [];
  
  // Prepare data for the chart
  const chartData = courses.map(c => ({
    name: c.name.replace('Matematika', 'Mat.'), // Shorten for display
    nilai: c.score,
    full: c.name
  }));

  const StatCard = ({ icon: Icon, label, value, color }: any) => (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex flex-col">
      <div className="flex items-center space-x-3 mb-4">
        <div className={`p-2 rounded-lg ${color}`}>
          <Icon className="w-5 h-5 text-white" />
        </div>
        <span className="text-slate-500 text-sm font-medium">{label}</span>
      </div>
      <span className="text-2xl font-bold text-slate-800">{value}</span>
    </div>
  );

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Selamat datang kembali, {user.name} 👋</h1>
        <p className="text-slate-500 mt-1">Berikut adalah ringkasan performa akademik Anda berdasarkan analisis data LMS.</p>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          icon={TrendingUp} 
          label="IPK (Estimasi)" 
          value={user.gpa.toFixed(2)} 
          color="bg-emerald-500" 
        />
        <StatCard 
          icon={Award} 
          label="Rata-rata Nilai" 
          value={`${user.mean_score_pct.toFixed(1)}%`} 
          color="bg-blue-500" 
        />
        <StatCard 
          icon={Clock} 
          label="Skor Engagement" 
          value={user.engagement_score} 
          color="bg-purple-500" 
        />
        <StatCard 
          icon={AlertCircle} 
          label="Kategori Performa" 
          value={user.performance_category} 
          color={user.performance_category === 'Low' ? 'bg-red-500' : 'bg-amber-500'} 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Chart */}
        <div className="lg:col-span-2 bg-white p-6 rounded-xl shadow-sm border border-slate-100">
          <h2 className="text-lg font-bold text-slate-800 mb-6">Performa Mata Kuliah</h2>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#64748b', fontSize: 12 }}
                  dy={10}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#64748b', fontSize: 12 }} 
                />
                <Tooltip 
                  cursor={{ fill: '#f1f5f9' }}
                  contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="nilai" fill="#22c55e" radius={[4, 4, 0, 0]} barSize={50} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Profile Summary */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
          <h2 className="text-lg font-bold text-slate-800 mb-6">Profil Belajar</h2>
          
          <div className="space-y-6">
            <div>
              <p className="text-sm text-slate-500 mb-2">Gaya Belajar</p>
              <span className="bg-red-50 text-red-600 px-3 py-1 rounded-full text-sm font-medium">
                {user.learning_style}
              </span>
            </div>

            <div>
              <p className="text-sm text-slate-500 mb-2">Klaster ML (Segmentasi)</p>
              <div className="flex flex-wrap gap-2">
                <span className="bg-slate-100 text-slate-600 px-3 py-1 rounded-md text-xs font-medium">
                  Cluster ID: {user.cluster}
                </span>
                <span className="bg-slate-100 text-slate-600 px-3 py-1 rounded-md text-xs font-medium">
                  Konsistensi: {user.consistency_score.toFixed(2)}
                </span>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100">
              <div className="bg-amber-50 p-4 rounded-lg border border-amber-100">
                <p className="text-xs text-amber-800 font-medium mb-1">Tips Pro</p>
                <p className="text-xs text-amber-700 leading-relaxed">
                  Perbarui aktivitas LMS Anda. Sistem mendeteksi korelasi tinggi antara frekuensi login dan nilai akhir pada Cluster {user.cluster}.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;