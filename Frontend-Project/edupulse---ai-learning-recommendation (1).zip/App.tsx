import React, { useState } from 'react';
import { HashRouter, Routes, Route, Link, useLocation, Navigate } from 'react-router-dom';
import { LayoutDashboard, User, BrainCircuit, LogOut, BookOpen, Users } from 'lucide-react';
import Dashboard from './components/Dashboard';
import Profile from './components/Profile';
import Recommendations from './components/Recommendations';
import AdminPanel from './components/AdminPanel';
import { MOCK_STUDENTS } from './data';
import { StudentData } from './types';

// Mock authentication context
const App: React.FC = () => {
  // Simulating logged in user (Siti Aminah - Medium Performer)
  const [currentUser, setCurrentUser] = useState<StudentData | null>(MOCK_STUDENTS[1]); 
  const [isAdmin, setIsAdmin] = useState(false);

  const handleLoginAsStudent = () => {
    setCurrentUser(MOCK_STUDENTS[1]);
    setIsAdmin(false);
  };

  const handleLoginAsAdmin = () => {
    setCurrentUser(null);
    setIsAdmin(true);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setIsAdmin(false);
  };

  if (!currentUser && !isAdmin) {
    return (
      <LoginScreen 
        onStudentLogin={handleLoginAsStudent} 
        onAdminLogin={handleLoginAsAdmin} 
      />
    );
  }

  return (
    <HashRouter>
      <div className="flex h-screen bg-slate-50">
        <Sidebar isAdmin={isAdmin} onLogout={handleLogout} />
        <main className="flex-1 overflow-y-auto p-8">
           <Routes>
             {isAdmin ? (
               <>
                 <Route path="/" element={<AdminPanel />} />
                 <Route path="*" element={<Navigate to="/" />} />
               </>
             ) : (
               <>
                 <Route path="/" element={<Dashboard user={currentUser!} />} />
                 <Route path="/profile" element={<Profile user={currentUser!} />} />
                 <Route path="/recommendations" element={<Recommendations user={currentUser!} />} />
                 <Route path="*" element={<Navigate to="/" />} />
               </>
             )}
           </Routes>
        </main>
      </div>
    </HashRouter>
  );
};

const LoginScreen = ({ onStudentLogin, onAdminLogin }: { onStudentLogin: () => void, onAdminLogin: () => void }) => (
  <div className="flex flex-col items-center justify-center h-screen bg-slate-100">
    <div className="bg-white p-8 rounded-xl shadow-lg w-96 text-center">
      <div className="flex justify-center mb-4">
        <div className="bg-red-600 p-3 rounded-lg">
          <BookOpen className="text-white w-8 h-8" />
        </div>
      </div>
      <h1 className="text-2xl font-bold text-slate-800 mb-2">EduPulse</h1>
      <p className="text-slate-500 mb-6">Learning Recommendation System</p>
      
      <div className="space-y-3">
        <button 
          onClick={onStudentLogin}
          className="w-full bg-red-600 hover:bg-red-700 text-white py-2 px-4 rounded-lg font-medium transition-colors"
        >
          Login as Student (Demo)
        </button>
        <button 
          onClick={onAdminLogin}
          className="w-full bg-slate-800 hover:bg-slate-900 text-white py-2 px-4 rounded-lg font-medium transition-colors"
        >
          Login as Admin
        </button>
      </div>
    </div>
  </div>
);

const Sidebar = ({ isAdmin, onLogout }: { isAdmin: boolean, onLogout: () => void }) => {
  const location = useLocation();
  
  const NavItem = ({ to, icon: Icon, label }: { to: string, icon: any, label: string }) => {
    const isActive = location.pathname === to;
    return (
      <Link 
        to={to} 
        className={`flex items-center space-x-3 px-4 py-3 rounded-lg mb-1 transition-colors ${
          isActive 
            ? 'bg-red-50 text-red-600 font-medium border-l-4 border-red-600' 
            : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
        }`}
      >
        <Icon className={`w-5 h-5 ${isActive ? 'text-red-600' : 'text-slate-400'}`} />
        <span>{label}</span>
      </Link>
    );
  };

  return (
    <div className="w-64 bg-white border-r border-slate-200 flex flex-col h-full">
      <div className="p-6 flex items-center space-x-3">
        <div className="bg-red-600 p-2 rounded-lg">
          <BookOpen className="text-white w-6 h-6" />
        </div>
        <span className="text-xl font-bold text-slate-800">EduPulse</span>
      </div>

      <nav className="flex-1 px-4 py-4">
        {isAdmin ? (
           <NavItem to="/" icon={Users} label="Manajemen Mahasiswa" />
        ) : (
          <>
            <NavItem to="/" icon={LayoutDashboard} label="Dasbor" />
            <NavItem to="/profile" icon={User} label="Profil & Nilai" />
            <NavItem to="/recommendations" icon={BrainCircuit} label="Rekomendasi AI" />
          </>
        )}
      </nav>

      <div className="p-4 border-t border-slate-100">
        <button 
          onClick={onLogout}
          className="flex items-center space-x-3 px-4 py-3 w-full text-slate-600 hover:bg-red-50 hover:text-red-600 rounded-lg transition-colors"
        >
          <LogOut className="w-5 h-5" />
          <span>Keluar</span>
        </button>
      </div>
    </div>
  );
};

export default App;
