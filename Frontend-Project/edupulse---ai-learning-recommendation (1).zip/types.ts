// Matches the structure of user_level_features_final_for_ML.csv
export interface StudentData {
  userid: number;
  mean_score_pct: number;
  num_attempts: number;
  engagement_score: number;
  consistency_score: number;
  performance_category: 'High' | 'Medium' | 'Low';
  cluster: number; // 0, 1, 2, 3
  
  // Simulated fields (since these aren't in the aggregated CSV but usually exist in DB)
  name: string;
  major: string;
  semester: number;
  gpa: number; // Simulated from mean_score
  learning_style: 'Visual' | 'Auditory' | 'Kinesthetic' | 'Reading/Writing';
}

export interface CourseGrade {
  code: string;
  name: string;
  score: number;
  sks: number;
}
